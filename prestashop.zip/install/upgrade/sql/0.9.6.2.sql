/* STRUCTURE */

ALTER TABLE `PREFIX_product` CHANGE `wholesale_price` `wholesale_price` DECIMAL(13, 6) NULL;

/*  CONTENTS */

/* CONFIGURATION VARIABLE */